﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour {

	public float moveSpeed;
	public float jumpHeight;
	public Rigidbody2D playerRB;
	public GameObject weaponHolder;
	ItemDatabase database;

	private int hpPlayer;
	public float warmthPlayer = 100f;
	public float hungerPlayer = 100f;

	public GameObject[] inventoryPlayer;

	public Inventory inv;
	public Item item;

	private string gogo;


	public int HpPlayer {

		get
		{ 
			return hpPlayer;
		}
		set
		{ 
			hpPlayer = value;
		}

	}

	// Use this for initialization
	void Start () {
		playerRB = GetComponent<Rigidbody2D> ();
		inv = GameObject.Find ("Inventory").GetComponent<Inventory> ();
	}
	
	public void EquipItem(string itemLoc, int slot, bool equipDifferentWeapon){
		Debug.Log ("descrption: " + itemLoc);

		if (weaponHolder.transform.childCount > 0) { //If the weaponholder is holding a weapon already
			
			if (equipDifferentWeapon == true) { //If player is tryin to equip a NEW/DIFFERENT item
				Destroy (weaponHolder.transform.GetChild (0).gameObject);

				UnityEngine.Object pPrefab = Resources.Load (itemLoc);
				GameObject prefabWeapon = (GameObject)GameObject.Instantiate (pPrefab, transform.localPosition, Quaternion.identity, weaponHolder.transform);
			}
		} else {
			
			UnityEngine.Object pPrefab = Resources.Load (itemLoc);
			GameObject prefabWeapon = (GameObject)GameObject.Instantiate (pPrefab, transform.localPosition, Quaternion.identity, weaponHolder.transform);

			Debug.Log ("you weren't carrying ANY weapon, so you've been assigned the weapon ID of what is in Slot zero");
		}

		//Instantiate (prefabWeapon, transform.localPosition, Quaternion.identity, weaponHolder.transform);
		if (item != null) {

		} else {
			
		}
			
	}

	public void IdentifyWeapon(int id){
		//string itemInfo = inv.slots [0].transform.GetChild(0).gameObject.GetComponent<ItemData>().item.Description;

		if (weaponHolder.transform.childCount > 0) {
			Debug.Log ("You have something equipped. So we'll have to swap that out");
				
			int newItem = inv.slots [id].gameObject.transform.GetChild (0).GetComponent<ItemData> ().item.Id;
			int currentItemEquipped = weaponHolder.transform.GetChild (0).GetComponent<ItemID> ().itemID;

			if (newItem == currentItemEquipped) {
				Debug.Log ("You already have this equipped.. Doing nothing");
				string go = inv.slots [id].gameObject.transform.GetChild(0).GetComponent<ItemData> ().item.Go;
				EquipItem (go, id, false);
			} else {
				string go = inv.slots [id].gameObject.transform.GetChild(0).GetComponent<ItemData> ().item.Go;
				EquipItem (go, id, true);
				//int go = inv.slots [id].transform.GetChild (id).gameObject.GetComponent<ItemData> ().item.Id;

			}

		} else //There is nothing in your weaponHolder
		{
			Debug.Log ("You have nothing in Slot 01");

			if (inv.slots [id].transform.childCount == 0) {
				//inv.AddItem (id);
				Debug.Log("You don't have any items in Slot: " + id);

			} else {
				string go = inv.slots [id].gameObject.transform.GetChild(0).GetComponent<ItemData> ().item.Go; //Gets the prefab path from our json items file
				EquipItem (go, id, false);
			}
		}


	}

	void FixedUpdate(){

		moveCharacter ();

	}

	void moveCharacter(){

		if (Input.GetKey (KeyCode.D))
			playerRB.AddForce (transform.right * moveSpeed);

		if (Input.GetKey (KeyCode.A))
			playerRB.AddForce (transform.right * -moveSpeed);

		if (Input.GetKeyDown (KeyCode.Space))
			playerRB.AddForce (transform.up * jumpHeight);

		if (Input.GetKeyDown (KeyCode.Alpha1)) {

			IdentifyWeapon (0);

		}

		if (Input.GetKeyDown (KeyCode.Alpha2)) {
			IdentifyWeapon (1);
		}

		if (Input.GetKeyDown (KeyCode.Alpha3)) {
			IdentifyWeapon (2);
		}
	}


}
