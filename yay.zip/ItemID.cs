﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemID : MonoBehaviour {

	public int ID;
	public int itemID;
	private GameObject SlotPanel;
	public string compareName;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		//ID = GameObject.Find (compareName).GetComponent<ItemData> ().slotId;
	}
}
